export const environment = {
  production: true,
  baseUrl: 'https://phpstack-742243-2492333.cloudwaysapps.com/backend/index.php/admin/API/'
  //baseUrl: 'http://93.188.162.210/lyca/backend/index.php/admin/API/'
};
