<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * API Controller
 */
class API extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
		header('Access-Control-Allow-Origin: *');
		header('Content-Type: application/json');
	}

	

	public function csr()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
		  $res = $this->Common->custom_query("SELECT * FROM tbl_csr WHERE status = '1' ");
			if (empty($res)) {
			  // print_r($res); die();
			  $result['success'] = false;
			  $result['message'] = 'No record found';
			  echo json_encode($result);
			  exit();
			}
			else
			{
			  $result['success'] = true;
			  $result['message'] = 'Success';
			  $result["data"]   = array();
			  foreach ($res as $row)
			  {
				$post = array();
				$post["csr_id"] = $row->csr_id;
				$post["title"] = $row->title;
				$post["csr_image"] = base_url($row->img_path);
				$post["read_more_url"] = $row->source_link;
				$post["description"] = $row->description;
				array_push($result["data"], $post);
			  }
			  echo json_encode($result);
			  exit();
			}
		  
		}
		else {
		  $result['success'] = false;
		  $result['message'] = "Authentication failed.";
		  echo json_encode($result);
		  exit();
		}
	}


	public function awards()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
		  $res = $this->Common->custom_query("SELECT * FROM tbl_awards WHERE status = '1' ");
			if (empty($res)) {
			  // print_r($res); die();
			  $result['success'] = false;
			  $result['message'] = 'No record found';
			  echo json_encode($result);
			  exit();
			}
			else
			{
			  $result['success'] = true;
			  $result['message'] = 'Success';
			  $result["data"]   = array();
			  foreach ($res as $row)
			  {
				$post = array();
				$post["awards_id"] = $row->awards_id;
				$post["title"] = $row->title;
				$post["year"] = $row->year;
				$post["award_image"] = base_url($row->img_path);
				$post["award_photo"] = base_url($row->photo_path);
				$post["description"] = $row->description;
				array_push($result["data"], $post);
			  }
			  echo json_encode($result);
			  exit();
			}
		  
		}
		else {
		  $result['success'] = false;
		  $result['message'] = "Authentication failed.";
		  echo json_encode($result);
		  exit();
		}
	}

	public function partners()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
		  $res = $this->Common->custom_query("SELECT * FROM tbl_partners WHERE status = '1' ");
			if (empty($res)) {
			  // print_r($res); die();
			  $result['success'] = false;
			  $result['message'] = 'No record found';
			  echo json_encode($result);
			  exit();
			}
			else
			{
			  $result['success'] = true;
			  $result['message'] = 'Success';
			  $result["data"]   = array();
			  foreach ($res as $row)
			  {
				$post = array();
				$post["partners_id"] = $row->partners_id;
				$post["title"] = $row->title;
				$post["image"] = base_url($row->img_path);
				array_push($result["data"], $post);
			  }
			  echo json_encode($result);
			  exit();
			}
		  
		}
		else {
		  $result['success'] = false;
		  $result['message'] = "Authentication failed.";
		  echo json_encode($result);
		  exit();
		}

	}

	public function movie_categories()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
		  $res = $this->Common->custom_query("SELECT * FROM tbl_category WHERE status = '1' ");
			if (empty($res)) {
			  // print_r($res); die();
			  $result['success'] = false;
			  $result['message'] = 'No record found';
			  echo json_encode($result);
			  exit();
			}
			else
			{
			  $result['success'] = true;
			  $result['message'] = 'Success';
			  $result["data"]   = array();
			  foreach ($res as $row)
			  {
				$post = array();
				$post["cat_id"] = $row->cat_id;
				$post["cat_name"] = $row->cat_name;
				array_push($result["data"], $post);
			  }
			  echo json_encode($result);
			  exit();
			}
		  
		}
		else {
		  $result['success'] = false;
		  $result['message'] = "Authentication failed.";
		  echo json_encode($result);
		  exit();
		}
	}

	// Movies API

	public function movies()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
		  if($this->input->post('order_by_field') != "") {
			$conds['order_by_field']   = $this->input->post('order_by');
			$conds['order_by_type']   = 'DESC';
			// $conds['order_by_type']   = $this->input->post('order_type');
		  }

		  if($this->input->post('movie_id') != "") {
			$conds['movie_id']   = $this->input->post('movie_id');
		  }

		  if($this->input->post('is_banner') != "") {
			$conds['is_banner']   = $this->input->post('is_banner');
		  }

		  $conds['status'] = 1;
		  // $conds['limit'] = 5;
		  // $conds['order_by'] = "DESC";
		  $res = $this->Movie_model->custom_conds($conds);

		  // print_r($res);die();
		  // $res = $this->Common->custom_query("SELECT m.*, c.cat_name FROM tbl_movie m INNER JOIN tbl_category c ON c.cat_id = m.cat_id WHERE m.status = '1' ");
			if (empty($res)) {
			  // print_r($res); die();
			  $result['success'] = false;
			  $result['message'] = 'No record found';
			  echo json_encode($result);
			  exit();
			}
			else
			{
			  $result['success'] = true;
			  $result['message'] = 'Success';
			  $result["data"]   = array();
			  foreach ($res as $row)
			  {
				$post = array();
				$post["movie_id"] = $row->movie_id;
				$post["cat_id"] = $row->cat_id;
				$post["cat_name"] = $row->cat_name;
				$post["movie_name"] = $row->movie_name;
				$post["video_url"] = $row->video_url;
				$post["thumb_img"] = base_url($row->thumb_img);
				$post["hover_img"] = base_url($row->hover_img);
				$post["banner_img"] = base_url($row->banner_img);
				$post["year"] = $row->year;
				$post["genre"] = $row->genre;
				$post["cast"] = $row->cast;
				$post["synopsis"] = $row->synopsis;
				$post["certification"] = $row->certification;
				$post["rating"] = $row->rating;
				$post["director"] = $row->director;
				$post["story"] = $row->story;
				$post["written_by"] = $row->written_by;
				$post["produced_by"] = $row->produced_by;
				$post["music_by"] = $row->music_by;
				$post["description"] = $row->description;
				array_push($result["data"], $post);
			  }
			  echo json_encode($result);
			  exit();
			}
		  
		}
		else {
		  $result['success'] = false;
		  $result['message'] = "Authentication failed.";
		  echo json_encode($result);
		  exit();
		}
	}
	
	//new release movies on home screen
	public function new_release_movies()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
			date_default_timezone_set('Asia/Kolkata');
			$today_date = date("Y-m-d");
			
			$cat_id = $this->input->post('cat_id');	
			
			if($cat_id != ''){
				$movie_list = $this->db->query("SELECT cat_id, movie_id, movie_name, thumb_img, hover_img FROM tbl_movie where cat_id = '".$cat_id."' and movie_date <= '".$today_date."' order by movie_date desc limit 16")->result_array();
				$movie_count = count($movie_list);
				
				if($movie_count != ''){
					for($i=0;$i<count($movie_list);$i++){
						$post[$i]["movie_id"] = $movie_list[$i]['movie_id'];
						$post[$i]["cat_id"] = $movie_list[$i]['cat_id'];
						$post[$i]["movie_name"] = $movie_list[$i]['movie_name'];
						$post[$i]["thumb_img"] = ASSETS."/img/movie/".$movie_list[$i]['thumb_img'];
						$post[$i]["hover_img"] = ASSETS."/img/movie/".$movie_list[$i]['hover_img'];
					}
				}else{
					$post = array();
				}
				
				$result['success'] = true;
				$result['message'] = 'Success';
				$result["data"]   = $post;
			  
				echo json_encode($result);
				exit();
			}else{
				$result['success'] = false;
				$result['message'] = "Authentication failed.";
				$result["data"]   = array();
				echo json_encode($result);
				exit();
			}	
		}
	}	
	
	//upcoming movies on home screen
	public function upcoming_movies()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
			date_default_timezone_set('Asia/Kolkata');
			$today_date = date("Y-m-d");
			
			$cat_id = $this->input->post('cat_id');	
			
			if($cat_id != ''){
				$movie_list = $this->db->query("SELECT cat_id, movie_id, movie_name, thumb_img, hover_img FROM tbl_movie where cat_id = '".$cat_id."' and movie_date >= '".$today_date."' order by movie_date desc limit 16")->result_array();
				$movie_count = count($movie_list);
				
				if($movie_count != ''){
					for($i=0;$i<count($movie_list);$i++){
						$post[$i]["movie_id"] = $movie_list[$i]['movie_id'];
						$post[$i]["cat_id"] = $movie_list[$i]['cat_id'];
						$post[$i]["movie_name"] = $movie_list[$i]['movie_name'];
						$post[$i]["thumb_img"] = ASSETS."/img/movie/".$movie_list[$i]['thumb_img'];
						$post[$i]["hover_img"] = ASSETS."/img/movie/".$movie_list[$i]['hover_img'];
					}
				}else{
					$post = array();
				}
				
				$result['success'] = true;
				$result['message'] = 'Success';
				$result["data"]   = $post;
			  
				echo json_encode($result);
				exit();
			}else{
				$result['success'] = false;
				$result['message'] = "Authentication failed.";
				$result["data"]   = array();
				echo json_encode($result);
				exit();
			}	
		}
	}
	
	//our movies on home screen	
	public function our_movies()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
			date_default_timezone_set('Asia/Kolkata');
			$today_date = date("Y-m-d");
			
			$cat_id = $this->input->post('cat_id');	
			
			if($cat_id != ''){
				$movie_list = $this->db->query("SELECT cat_id, movie_id, movie_name, thumb_img, hover_img FROM tbl_movie where cat_id = '".$cat_id."' and movie_date <= '".$today_date."' order by RAND() limit 16")->result_array();
				$movie_count = count($movie_list);
				
				if($movie_count != ''){
					for($i=0;$i<count($movie_list);$i++){
						$post[$i]["movie_id"] = $movie_list[$i]['movie_id'];
						$post[$i]["cat_id"] = $movie_list[$i]['cat_id'];
						$post[$i]["movie_name"] = $movie_list[$i]['movie_name'];
						$post[$i]["thumb_img"] = ASSETS."/img/movie/".$movie_list[$i]['thumb_img'];
						$post[$i]["hover_img"] = ASSETS."/img/movie/".$movie_list[$i]['hover_img'];
					}
				}else{
					$post = array();
				}
				
				$result['success'] = true;
				$result['message'] = 'Success';
				$result["data"]   = $post;
			  
				echo json_encode($result);
				exit();
			}else{
				$result['success'] = false;
				$result['message'] = "Authentication failed.";
				$result["data"]   = array();
				echo json_encode($result);
				exit();
			}	
		}
	}	
	
	// movies details screen	
	public function movie_details()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
			$movie_id = $this->input->post('movie_id');	
			
			if($movie_id != ''){
				$movie_list = $this->db->query("SELECT cat_id, movie_id, movie_name, video_url, banner_img, genre, cast, synopsis, synopsis_info, certification, certification_info, rating, rating_info, director, story, written_by, produced_by, music_by, imdb_rating, trailer_link, duration, duration_info, description  FROM tbl_movie where movie_id = '".$movie_id."' ")->result_array();
				$movie_count = count($movie_list);
				
				if($movie_count != ''){
					for($i=0;$i<count($movie_list);$i++){
						$post[$i]["movie_id"] = $movie_list[$i]['movie_id'];
						$post[$i]["cat_id"] = $movie_list[$i]['cat_id'];
						$post[$i]["movie_name"] = $movie_list[$i]['movie_name'];
						$post[$i]["video_url"] = $movie_list[$i]['video_url'];
						$post[$i]["genre"] = $movie_list[$i]['genre'];
						$post[$i]["cast"] = $movie_list[$i]['cast'];
						$post[$i]["synopsis"] = $movie_list[$i]['synopsis'];
						$post[$i]["synopsis_info"] = $movie_list[$i]['synopsis_info'];
						$post[$i]["certification"] = $movie_list[$i]['certification'];
						$post[$i]["certification_info"] = $movie_list[$i]['certification_info'];
						$post[$i]["rating"] = $movie_list[$i]['rating'];
						$post[$i]["rating_info"] = $movie_list[$i]['rating_info'];
						$post[$i]["director"] = $movie_list[$i]['director'];
						$post[$i]["story"] = $movie_list[$i]['story'];
						$post[$i]["written_by"] = $movie_list[$i]['written_by'];
						$post[$i]["produced_by"] = $movie_list[$i]['produced_by'];
						$post[$i]["music_by"] = $movie_list[$i]['music_by'];
						$post[$i]["imdb_rating"] = $movie_list[$i]['imdb_rating'];
						$post[$i]["trailer_link"] = $movie_list[$i]['trailer_link'];
						$post[$i]["duration"] = $movie_list[$i]['duration'];
						$post[$i]["duration_info"] = $movie_list[$i]['duration_info'];
						$post[$i]["description"] = $movie_list[$i]['description'];
						$post[$i]["banner_img"] = ASSETS."/img/movie/".$movie_list[$i]['banner_img'];
					}
				}else{
					$post = array();
				}
				
				$result['success'] = true;
				$result['message'] = 'Success';
				$result["data"]   = $post;
			  
				echo json_encode($result);
				exit();
			}else{
				$result['success'] = false;
				$result['message'] = "Authentication failed.";
				$result["data"]   = array();
				echo json_encode($result);
				exit();
			}	
		}
	}
	
	//recent news on home, screen
	public function latest_news()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
			$news_list = $this->db->query("SELECT * FROM tbl_news WHERE status = '1' order by news_id desc limit 3")->result_array();
			$news_count = count($news_list);
			
			if($news_count != ''){
				for($i=0;$i<count($news_list);$i++){
					$post[$i]["news_id"] = $news_list[$i]['news_id'];
					$post[$i]["title"] = $news_list[$i]['title'];
					$post[$i]["day"] = date("d", strtotime($news_list[$i]['news_date']));
					$post[$i]["month"] = date("M", strtotime($news_list[$i]['news_date']));
					$post[$i]["short_desc"] = $news_list[$i]['short_desc'];
					$post[$i]["source_name"] = $news_list[$i]['source_name'];
					$post[$i]["read_more_url"] = $news_list[$i]['read_more_url'];
					$post[$i]["img_path"] = ASSETS."/img/news/".$news_list[$i]['img_path'];
				}
			}else{
				$post = array();
			}
			
			$result['success'] = true;
			$result['message'] = 'Success';
			$result["data"]   = $post;
			
			echo json_encode($result);
			exit();
		}else {
			$result['success'] = false;
			$result['message'] = "Authentication failed.";
			echo json_encode($result);
			exit();
		}

	}
	
	
	public function news()
	{
		$api_token = api_token;
		if($this->input->post('api_token') == $api_token )
		{
			$news_list = $this->db->query("SELECT * FROM tbl_news WHERE status = '1' order by news_id desc")->result_array();
			$news_count = count($news_list);
			
			if($news_count != ''){
				for($i=0;$i<count($news_list);$i++){
					$post[$i]["news_id"] = $news_list[$i]['news_id'];
					$post[$i]["title"] = $news_list[$i]['title'];
					$post[$i]["day"] = date("d", strtotime($news_list[$i]['news_date']));
					$post[$i]["month"] = date("M", strtotime($news_list[$i]['news_date']));
					$post[$i]["short_desc"] = $news_list[$i]['short_desc'];
					$post[$i]["source_name"] = $news_list[$i]['source_name'];
					$post[$i]["read_more_url"] = $news_list[$i]['read_more_url'];
					$post[$i]["img_path"] = ASSETS."/img/news/".$news_list[$i]['img_path'];
				}
			}else{
				$post = array();
			}
			
			  $result['success'] = true;
			  $result['message'] = 'Success';
			  $result["data"]   = $post;
			  /*foreach ($res as $row)
			  {
				$post = array();
				$post["news_id"] = $row->news_id;
				$post["title"] = $row->title;
				$post["news_image"] = base_url($row->img_path);
				$post["news_date"] = date("d-m-Y", strtotime($row->news_date));
				$post["day"] = date("d", strtotime($row->news_date));
				$post["month"] = date("M", strtotime($row->news_date));
				$post["source_name"] = $row->source_name;
				$post["short_desc"] = $row->short_desc;
				$post["description"] = $row->description;
				$post["read_more_url"] = $row->read_more_url;
				array_push($result["data"], $post);
			  }*/
			  echo json_encode($result);
			  exit();
			
		  
		}
		else {
		  $result['success'] = false;
		  $result['message'] = "Authentication failed.";
		  echo json_encode($result);
		  exit();
		}

	}
}
?>