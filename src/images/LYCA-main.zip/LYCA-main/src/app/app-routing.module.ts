import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FooterComponent } from './components/layouts/footer/footer.component';
import { HeaderComponent } from './components/layouts/header/header.component';
import { PreloaderComponent } from './components/layouts/preloader/preloader.component';
import {QuicklinkStrategy } from 'ngx-quicklink';
import { NewsDetailsComponent } from './components/pages/news-details/news-details.component';
import { CsrDetailsComponent } from './components/pages/csr-details/csr-details.component';
import { MovieDetailsComponent } from './components/pages/movie-details/movie-details.component';

const routes: Routes = [
    {
      path: '', 
      loadChildren: () => import('./components/pages/home/home.module').then(m => m.HomeModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'home',
      loadChildren: () => import('./components/pages/home/home.module').then(m => m.HomeModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'hindi',
      loadChildren: () => import('./components/pages/hindi/hindi.module').then(m => m.HindiModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'indian2',
      loadChildren: () => import('./components/pages/indian/indian.module').then(m => m.IndianModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'tamil',
      loadChildren: () => import('./components/pages/tamil/tamil.module').then(m => m.TamilModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'telugu',
      loadChildren: () => import('./components/pages/telugu/telugu.module').then(m => m.TeluguModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      //path:'movie-details/:name',component: MovieDetailsComponent,
      path:'movie-details/:name',
      loadChildren: () => import('./components/pages/movie-details/movie-details.module').then(m => m.MovieDetailsModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'news',
      loadChildren: () => import('./components/pages/news/news.module').then(m => m.NewsModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'news-details/:name',component: NewsDetailsComponent,
      //loadChildren: () => import('./components/pages/news-details/news-details.module').then(m => m.NewsDetailsModule),
      //data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'csr',
      loadChildren: () => import('./components/pages/csr/csr.module').then(m => m.CsrModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'csr-details/:name',component: CsrDetailsComponent,
    },
    {
      path:'about',
      loadChildren: () => import('./components/pages/about/about.module').then(m => m.AboutModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'awards',
      loadChildren: () => import('./components/pages/awards/awards.module').then(m => m.AwardsModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'all-awards/:name',
      loadChildren: () => import('./components/pages/all-awards/all-awards.module').then(m => m.AllAwardsModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'other-awards',
      loadChildren: () => import('./components/pages/other-awards/other-awards.module').then(m => m.OtherAwardsModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'other-award-details/:name',
      loadChildren: () => import('./components/pages/other-award-details/other-award-details.module').then(m => m.OtherAwardDetailsModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'contact',
      loadChildren: () => import('./components/pages/contact/contact.module').then(m => m.ContactModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'privacy-policy',
      loadChildren: () => import('./components/pages/privacy-policy/privacy-policy.module').then(m => m.PrivacyPolicyModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
    {
      path:'terms-of-use',
      loadChildren: () => import('./components/pages/terms-of-use/terms-of-use.module').then(m => m.TermsOfUseModule),
      data: {title: 'Lyca',description:'', keywords:''} 
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes,  { preloadingStrategy: QuicklinkStrategy })],
    exports: [RouterModule]
  })
  export class AppRoutingModule { }

  export const routingComponents = [ PreloaderComponent,  HeaderComponent,FooterComponent,]
  