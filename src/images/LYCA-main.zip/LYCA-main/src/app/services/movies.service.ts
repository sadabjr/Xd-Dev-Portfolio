import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MoviesService {

  constructor(private http: HttpClient) { }

  newReleaseMovie(data:any) {
    return this.http.post(`${environment.baseUrl}new_release_movies`, data);
  }

  upcoming_movies(data:any) {
    return this.http.post(`${environment.baseUrl}upcoming_movies`, data);
  } 

  our_movies(data:any) {
    return this.http.post(`${environment.baseUrl}our_movies`, data);
  } 

  getLanguageNewMovieList(data:any) {
    return this.http.post(`${environment.baseUrl}new_release_movies_language`, data);
  } 

  
  getLanguageAllMoviesList(data:any) {
    return this.http.post(`${environment.baseUrl}all_movies_language`, data);
  } 

  getTopBannerList(data:any) {
    return this.http.post(`${environment.baseUrl}all_page_banner`, data);
  } 

  getParallexResult(data:any) {
    return this.http.post(`${environment.baseUrl}all_page_parallex`, data);
  } 

  getHomeBannerData(data:any) {
    return this.http.post(`${environment.baseUrl}home_banner`, data);
  } 

  getMovieDetailsData(data:any) {
    return this.http.post(`${environment.baseUrl}movie_details`, data);
  } 

}
