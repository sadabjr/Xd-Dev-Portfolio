import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CsrService {

  constructor(private http: HttpClient) { }

  csrData(data:any) {
    return this.http.post(`${environment.baseUrl}csr`, data);
  }

  csrDetails(data:any) {
    return this.http.post(`${environment.baseUrl}csr_details`, data);
  }

}
