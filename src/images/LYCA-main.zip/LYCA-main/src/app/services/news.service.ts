import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NewsService {

  constructor(private http: HttpClient) { }

  newsData(data:any) {
    return this.http.post(`${environment.baseUrl}news`, data);
  }

  latest_news(data:any) {
    return this.http.post(`${environment.baseUrl}latest_news`, data);
  } 

  newsDetails(data:any) {
    return this.http.post(`${environment.baseUrl}news_details`, data);
  }
   
}
