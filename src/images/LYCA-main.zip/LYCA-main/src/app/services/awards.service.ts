import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AwardsService {

  constructor(private http: HttpClient) { }

  ourFilmAwardsData(data:any) {
    return this.http.post(`${environment.baseUrl}our_film_awards`, data);
  }

  
  getAwardsDetailsData(data:any) {
    return this.http.post(`${environment.baseUrl}awards_movie_details`, data);
  } 

  ourOtherAwardsData(data:any) {
    return this.http.post(`${environment.baseUrl}other_awards_list`, data);
  } 

  getOtherAwardDetailsData(data:any) {
    return this.http.post(`${environment.baseUrl}other_awards_details`, data);
  } 
}
