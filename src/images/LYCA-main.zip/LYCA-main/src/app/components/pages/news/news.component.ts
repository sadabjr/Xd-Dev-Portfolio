import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { NewsService } from 'src/app/services/news.service';
import { MoviesService } from 'src/app/services/movies.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ContactService } from 'src/app/services/contact.service';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  result:any;
  newsList:any;
  p: number = 1;
  pagination: number = 1;
  getBannerData:any;
  subscribe:any;
  submitteds = false;
  resultTrue = false;
  submitted = false;
  resultFalse = false;

  constructor(
    private _newsService: NewsService,
    private _moviesService: MoviesService,
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    private _contactService: ContactService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.getNewsList();
    this.getTopBanner();
    this.subscribeForm();
  }

  get s() { return this.subscribe.controls; }

  subscribeForm() {
    this.subscribe = this.formBuilder.group({
      emailid: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    })
  }

  getNewsList() {
   

    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");

    this._newsService.newsData(formData).subscribe(res => {
      this.result = res;
      this.newsList = this.result.data;
      console.log(this.newsList);
    })
  }

  getTopBanner() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "4");

    this._moviesService.getTopBannerList(formData).subscribe(res => {
      this.result = res;
      this.getBannerData = this.result.data;
      console.log(this.getBannerData);
      // this.loadScript();
    })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

  blogDetails(id:any, title:any) {
    debugger;
    let slug = title.toString().toLowerCase()
      .replace(/\s+/g, '-')           // Replace spaces with -
      //.replace(/[^\w\-]+/g, '')       // Remove all non-word chars
      .replace(/\-\-+/g, '-')         // Replace multiple - with single -
      .replace(/^-+/, '')             // Trim - from start of text
      .replace(/-+$/, '');

     // console.log(slug);return false;
    this.router.navigate(['/news-details',  slug], { relativeTo: this._activatedRoute })
  }

  onSubscribe() {
    //this._router.navigate(['dashboard']);
    
    this.submitteds = true;
    if (this.subscribe.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      let email_id = this.subscribe.value.emailid;
      //console.log(email_id);return false;
      formData.append('email_id', email_id);
      
      this._contactService.subscribeData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.subscribe.reset();
          this.submitteds = false;
          
        }
       
      })
    }
  }
  
}
