import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { OtherAwardDetailsComponent } from './other-award-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

console.warn('Other Awards Details module loaded');

const otherAwardDetailsRoutes: Routes = [
  { path: '', component: OtherAwardDetailsComponent}
]

@NgModule({
  declarations: [OtherAwardDetailsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(otherAwardDetailsRoutes),
    FormsModule,
    ReactiveFormsModule
  ]
})
export class OtherAwardDetailsModule { }
