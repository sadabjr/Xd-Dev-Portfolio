import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllAwardsComponent } from './all-awards.component';

describe('AllAwardsComponent', () => {
  let component: AllAwardsComponent;
  let fixture: ComponentFixture<AllAwardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllAwardsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AllAwardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
