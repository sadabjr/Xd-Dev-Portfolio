import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { Router, ActivatedRoute} from '@angular/router';
import { ContactService } from 'src/app/services/contact.service';
import { MoviesService } from 'src/app/services/movies.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  submitted = false;
  resultFalse = false;
  resultTrue = false;
  select2 = false;
  selectedIndex:any;
  result:any;
  contact: any;
  getBannerData:any;
  subscribe:any;
  submitteds = false;

  constructor(
    private router:Router,
    private _activatedRoute:ActivatedRoute,
    private formBuilder: FormBuilder,
    private _contactService: ContactService,
    private _moviesService: MoviesService,
  ) { }

  ngOnInit(): void {
    this.contactForm();
    this.subscribeForm();
    this.getTopBanner();
  }

  get f() { return this.contact.controls; }

  get s() { return this.subscribe.controls; }

  setIndex(index: number) {
    this.selectedIndex = index;
  }

  contactForm() {
    this.contact = this.formBuilder.group({
      name: ['', Validators.required],
      email_id: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])],
      mobile: ['', Validators.compose([Validators.required, Validators.pattern('[0-9]*')])],
      message: [''],
    })
  }

  subscribeForm() {
    this.subscribe = this.formBuilder.group({
      emailid: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    })
  }

  onSubmit() {
    //this._router.navigate(['dashboard']);
    
    this.submitted = true;
    if (this.contact.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      

      let name = this.contact.value.name;
      let email_id = this.contact.value.email_id;
      let mobile = this.contact.value.mobile;
      let message = this.contact.value.message;

      formData.append('name', name);
      formData.append('email_id', email_id);
      formData.append('mobile', mobile);
      formData.append('message', message);

      /*formData.append('name', "Pankaj");
      formData.append('email_id', "pdhote@gmail.com");
      formData.append('mobile', "3698989898");
      formData.append('message', "olol");*/
      

     // console.log(formData);return false;

      this._contactService.contactData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.contact.reset();
          this.submitted = false;
          this.select2 = true;
        }
       
      })
    }

  }

  getTopBanner() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "8");

    this._moviesService.getTopBannerList(formData).subscribe(res => {
      this.result = res;
      this.getBannerData = this.result.data;
      console.log(this.getBannerData);
      // this.loadScript();
    })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

  
  onSubscribe() {
    //this._router.navigate(['dashboard']);
    
    this.submitteds = true;
    if (this.subscribe.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      let email_id = this.subscribe.value.emailid;
      //console.log(email_id);return false;
      formData.append('email_id', email_id);
      
      this._contactService.subscribeData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.subscribe.reset();
          this.submitteds = false;
          
        }
       
      })
    }

  }

}
