import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HindiComponent } from './hindi.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//import { HindiRoutingModule } from './hindi-routing.module';
console.warn('Hindi module loaded');

const hindiRoutes: Routes = [
  { path: '', component: HindiComponent}
]

@NgModule({
  declarations: [HindiComponent],
  imports: [
    CommonModule,
    //HindiRoutingModule
    RouterModule.forChild(hindiRoutes),
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class HindiModule { }
