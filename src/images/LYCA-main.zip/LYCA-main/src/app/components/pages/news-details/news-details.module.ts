import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { NewsDetailsComponent } from './news-details.component';

//import { NewsDetailsRoutingModule } from './news-details-routing.module';

const newsDetailsRoutes: Routes = [
  { path: '', component: NewsDetailsComponent}
]


@NgModule({
  declarations: [NewsDetailsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(newsDetailsRoutes)
  ]
})
export class NewsDetailsModule { }
