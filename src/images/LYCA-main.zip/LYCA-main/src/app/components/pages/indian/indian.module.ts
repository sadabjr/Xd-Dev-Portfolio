import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { IndianComponent } from './indian.component';


const indianRoutes: Routes = [
  { path: '', component: IndianComponent}
]

@NgModule({
  declarations: [IndianComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(indianRoutes),
  ]
})
export class IndianModule { }
