import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AwardsComponent } from './awards.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//import { AwardsRoutingModule } from './awards-routing.module';

console.warn('Awards module loaded');

const awardsRoutes: Routes = [
  { path: '', component: AwardsComponent}
]


@NgModule({
  declarations: [AwardsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(awardsRoutes),
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
    //AwardsRoutingModule
  ]
})
export class AwardsModule { }
