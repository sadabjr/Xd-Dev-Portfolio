import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AwardsService } from 'src/app/services/awards.service';
import { ContactService } from 'src/app/services/contact.service';

@Component({
  selector: 'app-all-awards',
  templateUrl: './all-awards.component.html',
  styleUrls: ['./all-awards.component.css']
})
export class AllAwardsComponent implements OnInit {
  id:any;
  result:any;
  awardsDetails:any;
  subscribe:any;
  submitteds = false;
  resultTrue = false;
  submitted = false;
  resultFalse = false;

  constructor(
    private _activatedRoute: ActivatedRoute,
    private router: Router,
    private _awardService: AwardsService,
    private _contactService: ContactService,
    private formBuilder: FormBuilder
  ) { }

  ngOnInit(): void {
    this.id = this._activatedRoute.snapshot.params.name;
    //console.log(this.id);
    this.getAwardsDetails(this.id);
    this.subscribeForm();
  }

  get s() { return this.subscribe.controls; }

  subscribeForm() {
    this.subscribe = this.formBuilder.group({
      emailid: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    })
  }

  getAwardsDetails(id:any) {
    //debugger;
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append('movie_name', id);
    //console.log(id);
    this._awardService.getAwardsDetailsData(formData).subscribe(res => {
      this.result = res;
      this.awardsDetails = this.result.data;
      console.log(this.awardsDetails);
    })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }
  
  onSubscribe() {
    //this._router.navigate(['dashboard']);
    
    this.submitteds = true;
    if (this.subscribe.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      let email_id = this.subscribe.value.emailid;
      //console.log(email_id);return false;
      formData.append('email_id', email_id);
      
      this._contactService.subscribeData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.subscribe.reset();
          this.submitteds = false;
          
        }
       
      })
    }
  }
  
}
