import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TeluguComponent } from './telugu.component';
import { RouterModule, Routes } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//import { TeluguRoutingModule } from './telugu-routing.module';

console.warn('Telugu module loaded');

const teluguRoutes: Routes = [
  { path: '', component: TeluguComponent}
]

@NgModule({
  declarations: [TeluguComponent],
  imports: [
    CommonModule,
    //TeluguRoutingModule
    RouterModule.forChild(teluguRoutes),
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class TeluguModule { }
