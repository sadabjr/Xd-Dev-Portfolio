import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MoviesService } from 'src/app/services/movies.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { NewsService } from 'src/app/services/news.service';
declare function loadImdbRating(data:any):any;

@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css']
})
export class MovieDetailsComponent implements OnInit {
  id:any;
  result:any;
  movieDetails:any;
  latstNewsList:any;
  safeurl: SafeResourceUrl | undefined;
  unsafeurl:any;
  trailer_link:any;
  modalvideo:any;

  constructor(
    public sanitizer: DomSanitizer, 
    private _activatedRoute: ActivatedRoute,
    private router: Router,
    private _movieDetailsService: MoviesService,
    private _newsService: NewsService
  ) { }

  ngOnInit(): void {
    this.id = this._activatedRoute.snapshot.params.name;
    console.log(this.id);
    this.getMovieDetails(this.id);
    this.latestNewsList();
    
    
  }

  getMovieDetails(id:any) {
    //debugger;
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append('movie_id', id);
    //console.log(id);
    this._movieDetailsService.getMovieDetailsData(formData).subscribe(res => {
      this.result = res;
      this.movieDetails = this.result.data;
      console.log(this.movieDetails);
      this.trailer_link = "https://www.youtube.com/embed/"+this.movieDetails[0].trailer_link;
      this.modalvideo = "https://www.youtube.com/watch?v="+this.movieDetails[0].trailer_link;
      
      let html = this.movieDetails[0].imdb_rating;
      this.loadScript(html);
     // this.safeurl = this.sanitizer.bypassSecurityTrustResourceUrl(this.trailer_link +'?&autoplay=0'); //+'?&autoplay=1'
      this.safeurl = this.sanitizer.bypassSecurityTrustResourceUrl(this.trailer_link);
    })
  }

  

  public loadScript(data:any) {
    setTimeout(function(){
      loadImdbRating(data);
    }, 1000);
  }

  latestNewsList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");

    this._newsService.latest_news(formData).subscribe(res => {
      this.result = res;
      this.latstNewsList = this.result.data;
      console.log(this.latstNewsList);
      // this.loadScript();
    })
  }

  blogDetails(id:any, title:any) {
    debugger;
    let slug = title.toString().toLowerCase()
      .replace(/\s+/g, '-')           // Replace spaces with -
      //.replace(/[^\w\-]+/g, '')       // Remove all non-word chars
      .replace(/\-\-+/g, '-')         // Replace multiple - with single -
      .replace(/^-+/, '')             // Trim - from start of text
      .replace(/-+$/, '');

     // console.log(slug);return false;
    this.router.navigate(['/news-details',  slug], { relativeTo: this._activatedRoute })
  }
  
  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

}
