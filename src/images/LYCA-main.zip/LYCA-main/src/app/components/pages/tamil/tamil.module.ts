import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TamilComponent } from './tamil.component';
import { RouterModule, Routes } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//import { TamilRoutingModule } from './tamil-routing.module';

console.warn('Tamil module loaded');

const tamilRoutes: Routes = [
  { path: '', component: TamilComponent}
]

@NgModule({
  declarations: [TamilComponent],
  imports: [
    CommonModule,
    //TamilRoutingModule
    RouterModule.forChild(tamilRoutes),
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class TamilModule { }
