import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { NewsComponent } from './news.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

console.warn('News module loaded');

const newsRoutes: Routes = [
  { path: '', component: NewsComponent}
]

@NgModule({
  declarations: [NewsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(newsRoutes),
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class NewsModule { }
