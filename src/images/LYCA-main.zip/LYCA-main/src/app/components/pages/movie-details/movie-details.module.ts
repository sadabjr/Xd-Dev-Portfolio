import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { MovieDetailsComponent } from './movie-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
//import { MovieDetailsRoutingModule } from './movie-details-routing.module';

const movieDetailsRoutes: Routes = [
  { path: '', component: MovieDetailsComponent}
]

@NgModule({
  declarations: [MovieDetailsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(movieDetailsRoutes),
    FormsModule,
    ReactiveFormsModule
    //MovieDetailsRoutingModule
  ]
})
export class MovieDetailsModule { }
