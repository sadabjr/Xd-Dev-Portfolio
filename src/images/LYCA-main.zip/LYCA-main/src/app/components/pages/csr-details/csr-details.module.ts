import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CsrDetailsComponent } from './csr-details.component';
import { CsrDetailsRoutingModule } from './csr-details-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [CsrDetailsComponent],
  imports: [
    CommonModule,
    CsrDetailsRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class CsrDetailsModule { }
