import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherAwardDetailsComponent } from './other-award-details.component';

describe('OtherAwardDetailsComponent', () => {
  let component: OtherAwardDetailsComponent;
  let fixture: ComponentFixture<OtherAwardDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OtherAwardDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherAwardDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
