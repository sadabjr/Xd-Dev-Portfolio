import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { OtherAwardsComponent } from './other-awards.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//import { OtherAwardsRoutingModule } from './other-awards-routing.module';

console.warn('Other Awards module loaded');

const otherAwardsRoutes: Routes = [
  { path: '', component: OtherAwardsComponent}
]

@NgModule({
  declarations: [OtherAwardsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(otherAwardsRoutes),
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
    //OtherAwardsRoutingModule
  ]
})
export class OtherAwardsModule { }
