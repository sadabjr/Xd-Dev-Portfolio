import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NewsService } from 'src/app/services/news.service';
import { MoviesService } from 'src/app/services/movies.service';

@Component({
  selector: 'app-news-details',
  templateUrl: './news-details.component.html',
  styleUrls: ['./news-details.component.css']
})
export class NewsDetailsComponent implements OnInit {
  id:any;
  newsDetails:any;
  result:any;
  getBannerData:any;
  
  constructor(
    private _activatedRoute: ActivatedRoute,
    private _moviesService: MoviesService,
    private _newsDetailsService: NewsService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.id = this._activatedRoute.snapshot.params.name;
    console.log(this.id);
    this.getNewsDetails(this.id);
    this.getTopBanner();
  }

  getNewsDetails(id:any) {
    //debugger;
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append('title', id);
    //console.log(id);
    this._newsDetailsService.newsDetails(formData).subscribe(res => {
      this.result = res;
      this.newsDetails = this.result.data;
      console.log(this.newsDetails);
    })
  }

  getTopBanner() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "4");

    this._moviesService.getTopBannerList(formData).subscribe(res => {
      this.result = res;
      this.getBannerData = this.result.data;
      console.log(this.getBannerData);
      // this.loadScript();
    })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

}
