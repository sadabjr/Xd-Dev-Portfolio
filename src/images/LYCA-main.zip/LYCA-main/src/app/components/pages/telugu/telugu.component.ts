import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { MoviesService } from 'src/app/services/movies.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ContactService } from 'src/app/services/contact.service';

declare function loadCarousel():any;

@Component({
  selector: 'app-telugu',
  templateUrl: './telugu.component.html',
  styleUrls: ['./telugu.component.css']
})
export class TeluguComponent implements OnInit {
  result:any;
  p: number = 1;
  pagination: number = 1;
  getLanguageNewMovie:any;
  getLanguageAllMovie:any;
  getBannerData:any;
  getParallexList:any;
  modalvideo:any;
  subscribe:any;
  submitteds = false;
  resultTrue = false;
  submitted = false;
  resultFalse = false;

  constructor(
    private _moviesService: MoviesService,
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    private _contactService: ContactService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.getTopBanner();
    this.getLanguageNewMoviesList();
    this.getLanguageAllMoviesList();
    this.getParallexData();
    this.subscribeForm();
  }

  get s() { return this.subscribe.controls; }

  subscribeForm() {
    this.subscribe = this.formBuilder.group({
      emailid: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    })
  }
  
  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

  getParallexData() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "3");

    this._moviesService.getParallexResult(formData).subscribe(res => {
      this.result = res;
      this.getParallexList = this.result.data;
      this.modalvideo = "https://www.youtube.com/watch?v="+this.getParallexList[0].trailer_link;
      console.log(this.getParallexList);
      // this.loadScript();
    })
  }

  getTopBanner() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "3");

    this._moviesService.getTopBannerList(formData).subscribe(res => {
      this.result = res;
      this.getBannerData = this.result.data;
      console.log(this.getBannerData);
      // this.loadScript();
    })
  }

  getLanguageNewMoviesList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("categoryid", "3");

    this._moviesService.getLanguageNewMovieList(formData).subscribe(res => {
      this.result = res;
      this.getLanguageNewMovie = this.result.data;
      console.log(this.getLanguageNewMovie);
      // this.loadScript();
    })
  }
  
  getLanguageAllMoviesList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("categoryid", "3");

    this._moviesService.getLanguageAllMoviesList(formData).subscribe(res => {
      this.result = res;
      this.getLanguageAllMovie = this.result.data;
      console.log(this.getLanguageAllMovie);
      // this.loadScript();
    })
  }

  public loadScript() {
    setTimeout(function(){
      loadCarousel();
    }, 1000);
  }

  ngAfterViewInit() {
    this.loadScript();
  }

  movieDetails(id:any, title:any) {
    debugger;
    let movieid = id;
    /*let slug = title.toString().toLowerCase()
      .replace(/\s+/g, '-')           // Replace spaces with -
      //.replace(/[^\w\-]+/g, '')       // Remove all non-word chars
      .replace(/\-\-+/g, '-')         // Replace multiple - with single -
      .replace(/^-+/, '')             // Trim - from start of text
      .replace(/-+$/, '');
    */
     // console.log(slug);return false;
    this.router.navigate(['/movie-details',  movieid], { relativeTo: this._activatedRoute })
  }

  onSubscribe() {
    //this._router.navigate(['dashboard']);
    
    this.submitteds = true;
    if (this.subscribe.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      let email_id = this.subscribe.value.emailid;
      //console.log(email_id);return false;
      formData.append('email_id', email_id);
      
      this._contactService.subscribeData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.subscribe.reset();
          this.submitteds = false;
          
        }
       
      })
    }
  }

}
