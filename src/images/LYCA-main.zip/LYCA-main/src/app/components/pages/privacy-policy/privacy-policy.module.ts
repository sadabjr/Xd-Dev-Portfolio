import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrivacyPolicyComponent } from './privacy-policy.component';
import { RouterModule, Routes } from '@angular/router';
//import { PrivacyPolicyRoutingModule } from './privacy-policy-routing.module';

const privacyRoutes: Routes = [
  { path: '', component: PrivacyPolicyComponent}
]

@NgModule({
  declarations: [PrivacyPolicyComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(privacyRoutes),
  ]
})
export class PrivacyPolicyModule { }
