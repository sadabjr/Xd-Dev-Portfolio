import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CsrService } from 'src/app/services/csr.service';
import { MoviesService } from 'src/app/services/movies.service';

@Component({
  selector: 'app-csr-details',
  templateUrl: './csr-details.component.html',
  styleUrls: ['./csr-details.component.css']
})
export class CsrDetailsComponent implements OnInit {
  id:any;
  csrDetails:any;
  result:any;
  getBannerData:any;

  constructor(
    private _activatedRoute: ActivatedRoute,
    private _csrDetailsService: CsrService,
    private router: Router,
    private _moviesService: MoviesService
  ) { }

  ngOnInit(): void {
    this.id = this._activatedRoute.snapshot.params.name;
    console.log(this.id);
    this.getCsrDetails(this.id);
    this.getTopBanner();
  }

  getCsrDetails(id:any) {
    //debugger;
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append('title', id);
    //console.log(id);
    this._csrDetailsService.csrDetails(formData).subscribe(res => {
      this.result = res;
      this.csrDetails = this.result.data;
      console.log(this.csrDetails);
    })
  }

  getTopBanner() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "5");

    this._moviesService.getTopBannerList(formData).subscribe(res => {
      this.result = res;
      this.getBannerData = this.result.data;
      console.log(this.getBannerData);
      // this.loadScript();
    })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

  
}
