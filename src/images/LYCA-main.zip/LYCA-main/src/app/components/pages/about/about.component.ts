import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { MoviesService } from 'src/app/services/movies.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ContactService } from 'src/app/services/contact.service';
declare function loadCarousel():any;
declare function applySlider():any;

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  getBannerData:any;
  result:any;
  getBusiness:any;
  subscribe:any;
  submitteds = false;
  resultTrue = false;
  submitted = false;
  resultFalse = false;

  constructor(
    private _moviesService: MoviesService,
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    private _contactService: ContactService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.getTopBanner();
    this.getBusinessData();
    this.subscribeForm();
  }

  get s() { return this.subscribe.controls; }

  subscribeForm() {
    this.subscribe = this.formBuilder.group({
      emailid: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    })
  }

  getTopBanner() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "6");

    this._moviesService.getTopBannerList(formData).subscribe(res => {
      this.result = res;
      this.getBannerData = this.result.data;
      console.log(this.getBannerData);
      // this.loadScript();
    })
  }

  getBusinessData() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    

    this._contactService.getBusinessDataList(formData).subscribe(res => {
      this.result = res;
      this.getBusiness = this.result.data;
      console.log(this.getBusiness);
      // this.loadScript();
    })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

  public loadScript() {
    setTimeout(function(){
      applySlider();
    }, 500);
        // var dynamicScripts = ["/assets/js/custom.js"];
        // for (var i = 0; i < dynamicScripts.length; i++) {
        //   if(i = 0){
        //     let node = document.createElement('script');
        //     node.src = dynamicScripts [i];
        //     node.type = 'text/javascript';
        //     node.async = true;
        //     node.charset = 'utf-8';
        //     document.getElementsByTagName('head')[0].appendChild(node);
        //   }
        // }
  }
  ngAfterViewInit() {
    this.loadScript();
  }
  
  onSubscribe() {
    //this._router.navigate(['dashboard']);
    
    this.submitteds = true;
    if (this.subscribe.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      let email_id = this.subscribe.value.emailid;
      //console.log(email_id);return false;
      formData.append('email_id', email_id);
      
      this._contactService.subscribeData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.subscribe.reset();
          this.submitteds = false;
          
        }
       
      })
    }
  }

}
