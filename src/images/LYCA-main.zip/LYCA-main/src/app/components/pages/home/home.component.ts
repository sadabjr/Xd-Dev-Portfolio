import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { Router, ActivatedRoute} from '@angular/router';
import { MoviesService } from 'src/app/services/movies.service';
import { NewsService } from 'src/app/services/news.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ContactService } from 'src/app/services/contact.service';
declare function loadCarousel():any;
//declare function loadImdbRating(data:any):any;
declare function loadImdbRatingMulti(data:any,num:any):any;

// declare function owlinitial():any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {
  result:any; 
  newReleaseMovieList:any;
  newReleaseMovieList1:any;
  newReleaseMovieList2:any;
  upcomingMovieList:any;
  ourMovieList:any;
  latstNewsList:any;
  getParallexList:any;
  getBannerList:any;
  start = 0;
  safeurl: SafeResourceUrl | undefined;
  unsafeurl:any;
  short_trailer_link:any;
  modalvideo:any;
  subscribe:any;
  submitteds = false;
  resultTrue = false;
  submitted = false;
  resultFalse = false;

  constructor(
    public sanitizer: DomSanitizer, 
    private router:Router,
    private _activatedRoute:ActivatedRoute,
    private _moviesService: MoviesService,
    private _newsService: NewsService,
    private _contactService: ContactService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.getParallexData();
    this.getNewReleaseMoviesList();
    this.getUpcomingMoviesList();
    this.ourMoviesList();
    this.latestNewsList();
    this.latestHomeBannerList();
    this.subscribeForm();
  }

  get s() { return this.subscribe.controls; }

  subscribeForm() {
    this.subscribe = this.formBuilder.group({
      emailid: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    })
  }
/*
  latestHomeBannerList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    
    this._moviesService.getHomeBannerData(formData).subscribe(res => {
      this.result = res;
      this.getBannerList = this.result.data;
      let html = this.getBannerList[0].imdb_rating;
      this.loadScript1(html);
      this.short_trailer_link = this.getBannerList[0].short_trailer_link;
      this.safeurl = this.sanitizer.bypassSecurityTrustResourceUrl('http://93.188.162.210/lyca/backend/assets/img/movie/trailer/'+this.short_trailer_link);
      console.log(this.getBannerList);
      // this.loadScript();
    })
  }

  public loadScript1(data:any) {
    setTimeout(function(){
      loadImdbRating(data);
    }, 1000);
  }*/

  latestHomeBannerList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    this._moviesService.getHomeBannerData(formData).subscribe(res => {
      this.result = res;
      this.getBannerList = this.result.data;
      for (let i = 0; i < this.getBannerList.length; i++) {
        let html = this.getBannerList[i].imdb_rating;
        this.loadScript1(html, i);
        this.short_trailer_link = this.getBannerList[i].short_trailer_link;
        // this.getBannerList[i].safeurl = this.sanitizer.bypassSecurityTrustResourceUrl('http://93.188.162.210/lyca/backend/assets/img/movie/trailer/'+this.getBannerList[i].short_trailer_link);
      }
      console.log(this.getBannerList);
      // this.loadScript();
    })
  }
  public loadScript1(data:any, num:any) {
    setTimeout(function(){
      loadImdbRatingMulti(data,num);
    }, 1000);
  }

  getParallexData() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "0");

    this._moviesService.getParallexResult(formData).subscribe(res => {
      this.result = res;
      this.getParallexList = this.result.data;
      this.modalvideo = "https://www.youtube.com/watch?v="+this.getParallexList[0].trailer_link;
      //this.short_trailer_link = this.getBannerList[0].trailer_link;
      //this.modalvideo = this.sanitizer.bypassSecurityTrustResourceUrl(this.short_trailer_link);
      console.log(this.modalvideo);
      // this.loadScript();
    })
  }

  getNewReleaseMoviesList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");

    this._moviesService.newReleaseMovie(formData).subscribe(res => {
      this.result = res;
      this.newReleaseMovieList = this.result.data;
      console.log(this.newReleaseMovieList);
      // this.loadScript();
    })
  }

  getUpcomingMoviesList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");

    this._moviesService.upcoming_movies(formData).subscribe(res => {
      this.result = res;
      this.upcomingMovieList = this.result.data;
      console.log(this.upcomingMovieList);
      // this.loadScript();
    })
  }

  ourMoviesList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");

    this._moviesService.our_movies(formData).subscribe(res => {
      this.result = res;
      this.ourMovieList = this.result.data;
      console.log(this.ourMovieList);
      // this.loadScript();
    })
  }

  latestNewsList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");

    this._newsService.latest_news(formData).subscribe(res => {
      this.result = res;
      this.latstNewsList = this.result.data;
      console.log(this.latstNewsList);
      // this.loadScript();
    })
  }

  public loadScript() {
    setTimeout(function(){
      loadCarousel();
    }, 1000);
        // var dynamicScripts = ["/assets/js/custom.js"];
        // for (var i = 0; i < dynamicScripts.length; i++) {
        //   if(i = 0){
        //     let node = document.createElement('script');
        //     node.src = dynamicScripts [i];
        //     node.type = 'text/javascript';
        //     node.async = true;
        //     node.charset = 'utf-8';
        //     document.getElementsByTagName('head')[0].appendChild(node);
        //   }
        // }
  }
  ngAfterViewInit() {
    this.loadScript();
  }

  movieDetails(id:any, title:any) {
    debugger;
    let movieid = id;
    //let slug = title.toString().toLowerCase()
    /*  .replace(/\s+/g, '-')           // Replace spaces with -
      //.replace(/[^\w\-]+/g, '')       // Remove all non-word chars
      .replace(/\-\-+/g, '-')         // Replace multiple - with single -
      .replace(/^-+/, '')             // Trim - from start of text
      .replace(/-+$/, '');
    */
     // console.log(slug);return false;
    this.router.navigate(['/movie-details',  movieid], { relativeTo: this._activatedRoute })
  }

  blogDetails(id:any, title:any) {
    debugger;
    let slug = title.toString().toLowerCase()
      .replace(/\s+/g, '-')           // Replace spaces with -
      //.replace(/[^\w\-]+/g, '')       // Remove all non-word chars
      .replace(/\-\-+/g, '-')         // Replace multiple - with single -
      .replace(/^-+/, '')             // Trim - from start of text
      .replace(/-+$/, '');

     // console.log(slug);return false;
    this.router.navigate(['/news-details',  slug], { relativeTo: this._activatedRoute })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }
  
  onSubscribe() {
    //this._router.navigate(['dashboard']);
    
    this.submitteds = true;
    if (this.subscribe.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      let email_id = this.subscribe.value.emailid;
      //console.log(email_id);return false;
      formData.append('email_id', email_id);
      
      this._contactService.subscribeData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.subscribe.reset();
          this.submitteds = false;
          
        }
       
      })
    }
  }
  
}
