import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CsrDetailsComponent } from './csr-details.component';

describe('CsrDetailsComponent', () => {
  let component: CsrDetailsComponent;
  let fixture: ComponentFixture<CsrDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CsrDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CsrDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
