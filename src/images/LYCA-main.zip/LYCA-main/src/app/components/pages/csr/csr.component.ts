import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { CsrService } from 'src/app/services/csr.service';
import { MoviesService } from 'src/app/services/movies.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ContactService } from 'src/app/services/contact.service';

@Component({
  selector: 'app-csr',
  templateUrl: './csr.component.html',
  styleUrls: ['./csr.component.css']
})
export class CsrComponent implements OnInit {
  result:any;
  csrList:any;
  p: number = 1;
  pagination: number = 1;
  getBannerData:any;
  subscribe:any;
  submitteds = false;
  resultTrue = false;
  submitted = false;
  resultFalse = false;

  constructor(
    private _csrService: CsrService,
    private _moviesService: MoviesService,
    private router: Router,
    private _activatedRoute: ActivatedRoute,
    private _contactService: ContactService,
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit(): void {
    this.getCsrList();
    this.getTopBanner();
    this.subscribeForm();
  }

  get s() { return this.subscribe.controls; }

  subscribeForm() {
    this.subscribe = this.formBuilder.group({
      emailid: ['', Validators.compose([
        Validators.required,
        Validators.email
      ])]
    })
  }

  getCsrList() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");

    this._csrService.csrData(formData).subscribe(res => {
      this.result = res;
      this.csrList = this.result.data;
      console.log(this.csrList);
    })
  }

  getTopBanner() {
    const formData = new FormData();
    formData.append("api_token", "LyC@Pro!#");
    formData.append("pageid", "5");

    this._moviesService.getTopBannerList(formData).subscribe(res => {
      this.result = res;
      this.getBannerData = this.result.data;
      console.log(this.getBannerData);
      // this.loadScript();
    })
  }

  trackByFn(index:any, item:any) {
    return index; // or item.id
  }

  csrDetails(id:any, title:any) {
    debugger;
    let slug = title.toString().toLowerCase()
      .replace(/\s+/g, '-')           // Replace spaces with -
      //.replace(/[^\w\-]+/g, '')       // Remove all non-word chars
      .replace(/\-\-+/g, '-')         // Replace multiple - with single -
      .replace(/^-+/, '')             // Trim - from start of text
      .replace(/-+$/, '');

     // console.log(slug);return false;
    this.router.navigate(['/csr-details',  slug], { relativeTo: this._activatedRoute })
  }

  onSubscribe() {
    //this._router.navigate(['dashboard']);
    
    this.submitteds = true;
    if (this.subscribe.invalid) {
      return;
    }
    else {
      const formData = new FormData();
      let email_id = this.subscribe.value.emailid;
      //console.log(email_id);return false;
      formData.append('email_id', email_id);
      
      this._contactService.subscribeData(formData).subscribe(res => {
        //this.router.navigate(['thank-you']);
        let response:any = res;
           
        if(response['result'] == 'F') {
          this.resultFalse = true;
          this.resultTrue = false;
       
        } else {  
          this.resultFalse = false;
          this.resultTrue = true;
          this.subscribe.reset();
          this.submitteds = false;
          
        }
       
      })
    }
  }
  
}
