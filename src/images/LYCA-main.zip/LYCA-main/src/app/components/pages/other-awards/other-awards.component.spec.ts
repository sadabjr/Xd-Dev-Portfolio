import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OtherAwardsComponent } from './other-awards.component';

describe('OtherAwardsComponent', () => {
  let component: OtherAwardsComponent;
  let fixture: ComponentFixture<OtherAwardsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OtherAwardsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OtherAwardsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
