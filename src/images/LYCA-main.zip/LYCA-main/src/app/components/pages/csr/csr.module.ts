import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

//import { CsrRoutingModule } from './csr-routing.module';
import { CsrComponent } from './csr.component';
import { RouterModule, Routes } from '@angular/router';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

console.warn('Csr module loaded');

const csrRoutes: Routes = [
  { path: '', component: CsrComponent}
]

@NgModule({
  declarations: [CsrComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(csrRoutes),
    NgxPaginationModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class CsrModule { }
