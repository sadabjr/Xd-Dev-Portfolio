import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AllAwardsComponent } from './all-awards.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

//import { AllAwardsRoutingModule } from './all-awards-routing.module';

const allAwardsRoutes: Routes = [
  { path: '', component: AllAwardsComponent}
]

@NgModule({
  declarations: [AllAwardsComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(allAwardsRoutes),
    FormsModule,
    ReactiveFormsModule
    //AllAwardsRoutingModule
  ]
})
export class AllAwardsModule { }
