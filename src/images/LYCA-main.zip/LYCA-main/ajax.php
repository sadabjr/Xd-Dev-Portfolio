<?php

    $host = "localhost";
    $user_name = "root";
    $password = "";
    $db_name = "destek_lyca_admin";

    $conn = mysqli_connect($host,$user_name,$password,$db_name);

    if(!$conn) {
        // die("Connection failed: " . mysqli_connect_error());
    }

    if(isset($_GET["movieId"]) && !empty($_GET["movieId"]))
    {
        $movie_id = $_GET['movieId'];
        $query = $conn->query("SELECT m.*, c.cat_name FROM tbl_movie m INNER JOIN tbl_category c ON c.cat_id = m.cat_id WHERE movie_id = '$movie_id' ");
        // print_r($query);die();
        $rowCount = $query->num_rows;
        
        //Display Movie details
        if($rowCount > 0){
            while($row = $query->fetch_assoc())
            { 
                $getDBid = $row["movie_id"];
                $cat_id = $row['cat_id'];
                $movie_name = $row['movie_name'];
                $video_url = $row['video_url'];
                $thumb_img = $row['thumb_img'];
                $hover_img = $row['hover_img'];
                $banner_img = $row['banner_img'];
                $year = $row['year'];
                $genre = $row['genre'];
                $cast = $row['cast'];
                $synopsis = $row['synopsis'];
                $synopsis_info = $row['synopsis_info'];
                $certification = $row['certification'];
                $certification_info = $row['certification_info'];
                $rating = $row['rating'];
                $rating_info = $row['rating_info'];
                $director = $row['director'];
                $story = $row['story'];
                $written_by = $row['written_by'];
                $produced_by = $row['produced_by'];
                $music_by = $row['music_by'];
                $imdb_rating = $row['imdb_rating'];
                $trailer_link = $row['trailer_link'];
                $movie_date = $row['movie_date'];
                $duration = $row['duration'];
                $duration_info = $row['duration_info'];
                $description = $row['description'];

                $bg_img = "'img/blog/blog_thumb01.jpg'";
            }
            echo '<section style="background-image: url('.$bg_img.'); background-size: cover; opacity: 1;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <div class="row" style="padding-top:150px !important;">
                      <div class="col-md-9">
                        <div class="movie-details-content">
                          <ul style="display:inline-block;">
                            <li><i class="far fa-calendar-alt"></i></li>
                            <li><i class="far fa-calendar-alt"></i></li>
                          </ul>
                          <h5 style="color:#fff;">Movie name</h5>
                          <p>Description of movie</p>
                          <br>
                          <div class="banner-meta">
                              <ul>
                                  <li class="quality">
                                      <span>Pg 18</span>
                                      <span>hd</span>
                                  </li>
                                  <li class="category">
                                      <a href="#">Romance,</a>
                                      <a href="#">Drama</a>
                                  </li>
                                  <li class="release-time">
                                      <span><i class="far fa-calendar-alt"></i> 2021</span>
                                      <span><i class="far fa-clock"></i> 128 min</span>
                                  </li>
                              </ul>
                          </div>
                        </div>
                      </div>

                      <div class="col-md-3">
                        <div class="movie-details-prime">
                          <ul style="background: #242c38b0;">
                              <li class="streaming">
                                <h6>Prime Video</h6>
                                <span>Ajay Devgan</span>
                              </li>
                              <li class="watch"><a href="https://www.youtube.com/watch?v=R2gbPxeNk2E" class="btn popup-video"><i class="fas fa-play"></i> View More</a></li>
                          </ul>
                        </div>
                      </div>

                    </div>
                </section>';
        }
        else{
            echo '<button type="button" class="close" data-dismiss="modal">&times;</button>';
            echo '<h3 style="color:#000;">No data available</h3>';
        }
    }
?>